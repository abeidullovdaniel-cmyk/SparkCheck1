SparkCheck 1.3 - проверка игроков на читы с GUI (Paper/Purpur 1.21.x, LuckPerms, LiteBans)

Сборка:  mvn clean package   (нужны JDK 21 и Maven)
Jar:     target/SparkCheck-1.3.jar -> положить в папку plugins

КОМАНДЫ (алиасы /check, /scheck)
  /sparkcheck                      меню со списком игроков
  /sparkcheck <игрок> [место]      вызвать на проверку (место необязательно)
  /sparkcheck list | history       активные проверки / история
  /sparkcheck end <игрок> <clean|cheats|refused|cancel>
  /sparkcheck rooms                меню мест проверки
  /sparkcheck setroom [имя]        сохранить текущую позицию как место (по умолчанию имя main)
  /sparkcheck room <имя|none>      место по умолчанию (none - проверять на месте, без телепорта)
  /sparkcheck delroom <имя>        удалить место
  /sparkcheck reload               перезагрузка конфига
  /report <ник>                    для игроков: пожаловаться (меню причин)
  /sparkcheck reports              репорты на игроков (меню модератора); take <id>, release <id>
  /confess [confirm]               для игрока на проверке: признание (алиасы /признаюсь, /признание)

ПРАВА (LuckPerms)
  Группы:
    sparkcheck.moderator   всё для проведения проверок
    sparkcheck.admin       moderator + места проверки + reload
    sparkcheck.*           всё
  Отдельные права:
    sparkcheck.use              меню, вызов на проверку, список
    sparkcheck.history          история проверок
    sparkcheck.inventory        просмотр инвентаря игрока
    sparkcheck.notify           уведомления о проверках других модераторов
    sparkcheck.verdict.clean    вердикт "Чист"
    sparkcheck.verdict.punish   вердикты "Читы" и "Отказ" (наказание)
    sparkcheck.verdict.cancel   отмена проверки
    sparkcheck.room.move        менять место во время проверки
    sparkcheck.room             создавать/удалять места, место по умолчанию
    sparkcheck.reload           /sparkcheck reload
    sparkcheck.confess          /confess (по умолчанию есть у всех)
    sparkcheck.report           /report (по умолчанию есть у всех)
    sparkcheck.reports          список репортов в меню, взять репорт
    sparkcheck.reports.notify   новые репорты в чат
    sparkcheck.reports.manage   вернуть/закрыть репорт другого модератора
    sparkcheck.bypass           игрока нельзя вызвать на проверку (по умолчанию нет ни у кого)

  Примеры:
    /lp group moderator permission set sparkcheck.moderator true
    /lp group admin permission set sparkcheck.admin true
    /lp group owner permission set sparkcheck.bypass true
    /lp group default permission set sparkcheck.confess true

LITEBANS
  Наказания - команды консоли из раздела commands в config.yml (по умолчанию "ban <игрок> 30d <причина> -s").
  Срок и причину меняйте там же. Убрать "-s", если нужно стандартное оповещение LiteBans.
