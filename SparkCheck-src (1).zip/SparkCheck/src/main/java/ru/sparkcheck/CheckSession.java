package ru.sparkcheck;

import net.kyori.adventure.bossbar.BossBar;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.UUID;

/** Одна активная проверка: модератор + подозреваемый. */
public final class CheckSession {
    public final UUID suspect;
    public final String suspectName;
    public final UUID moderator;
    public final String moderatorName;
    public final long start;
    public long end;
    public long total;

    public Location suspectOrigin;
    public Location moderatorOrigin;
    public boolean frozen = true;
    public boolean timeoutNotified;
    public String contact;
    public String room = "";
    public long confessAt;
    public int reportId;          // репорт, из которого начата проверка (0 - нет)
    public long lastReminder;
    public BossBar bar;

    public CheckSession(Player suspect, Player moderator, long totalMs) {
        this.suspect = suspect.getUniqueId();
        this.suspectName = suspect.getName();
        this.moderator = moderator.getUniqueId();
        this.moderatorName = moderator.getName();
        this.start = System.currentTimeMillis();
        this.total = totalMs;
        this.end = start + totalMs;
        this.lastReminder = start;
    }

    /** Сколько осталось (мс), может быть отрицательным. */
    public long left() {
        return end - System.currentTimeMillis();
    }

    /** Добавить время. Если время уже вышло (режим notify), отсчёт идёт от текущего момента. */
    public void addTime(long ms) {
        long now = System.currentTimeMillis();
        end = Math.max(end, now) + ms;
        total = Math.max(total, end - now);
        timeoutNotified = false;
    }
}
