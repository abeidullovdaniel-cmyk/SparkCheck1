package ru.sparkcheck;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/** Вся логика проверок: старт, таймер, вердикты, признание, места проверки, история. */
public final class CheckManager {

    public record HistoryEntry(String suspect, String moderator, Verdict verdict,
                               long time, long durationSec, String contact) {
    }

    private static final int MAX_HISTORY = 200;
    private static final Pattern ROOM_NAME = Pattern.compile("[a-z0-9_\\-]{1,24}");

    private final SparkCheck plugin;
    private final Map<UUID, CheckSession> sessions = new ConcurrentHashMap<>();
    private final List<HistoryEntry> history = new ArrayList<>();
    private final File historyFile;
    private final File roomsFile;
    private YamlConfiguration rooms;

    public CheckManager(SparkCheck plugin) {
        this.plugin = plugin;
        this.historyFile = new File(plugin.getDataFolder(), "history.yml");
        this.roomsFile = new File(plugin.getDataFolder(), "rooms.yml");
        loadHistory();
        loadRooms();
    }

    // ---------------- доступ ----------------

    public CheckSession get(UUID suspect) {
        return sessions.get(suspect);
    }

    public boolean isChecked(UUID suspect) {
        return sessions.containsKey(suspect);
    }

    public boolean hasSessions() {
        return !sessions.isEmpty();
    }

    public Collection<CheckSession> all() {
        return new ArrayList<>(sessions.values());
    }

    public List<CheckSession> sessionsOf(UUID moderator) {
        List<CheckSession> out = new ArrayList<>();
        for (CheckSession s : sessions.values()) {
            if (s.moderator.equals(moderator)) out.add(s);
        }
        return out;
    }

    public List<HistoryEntry> history() {
        return Collections.unmodifiableList(history);
    }

    // ---------------- места проверки (rooms.yml) ----------------

    private void loadRooms() {
        if (roomsFile.exists()) {
            rooms = YamlConfiguration.loadConfiguration(roomsFile);
            return;
        }
        rooms = new YamlConfiguration();
        // миграция со старой версии, где было одно место в config.yml (раздел room)
        ConfigurationSection old = plugin.getConfig().getConfigurationSection("room");
        if (old != null && old.getString("world") != null) {
            rooms.set("rooms.main.world", old.getString("world"));
            rooms.set("rooms.main.x", old.getDouble("x"));
            rooms.set("rooms.main.y", old.getDouble("y"));
            rooms.set("rooms.main.z", old.getDouble("z"));
            rooms.set("rooms.main.yaw", old.getDouble("yaw"));
            rooms.set("rooms.main.pitch", old.getDouble("pitch"));
            rooms.set("default", "main");
            saveRooms();
        }
    }

    private void saveRooms() {
        try {
            plugin.getDataFolder().mkdirs();
            rooms.save(roomsFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Не удалось сохранить rooms.yml: " + e.getMessage());
        }
    }

    public boolean validRoomName(String name) {
        return name != null && ROOM_NAME.matcher(name.toLowerCase(Locale.ROOT)).matches();
    }

    public List<String> roomNames() {
        ConfigurationSection sec = rooms.getConfigurationSection("rooms");
        List<String> out = new ArrayList<>();
        if (sec != null) out.addAll(sec.getKeys(false));
        Collections.sort(out);
        return out;
    }

    public boolean roomExists(String name) {
        return name != null && rooms.isConfigurationSection("rooms." + name.toLowerCase(Locale.ROOT));
    }

    /** Локация места или null, если места нет или его мир не загружен. */
    public Location room(String name) {
        if (name == null) return null;
        ConfigurationSection r = rooms.getConfigurationSection("rooms." + name.toLowerCase(Locale.ROOT));
        if (r == null) return null;
        World w = Bukkit.getWorld(r.getString("world", ""));
        if (w == null) return null;
        return new Location(w, r.getDouble("x"), r.getDouble("y"), r.getDouble("z"),
                (float) r.getDouble("yaw"), (float) r.getDouble("pitch"));
    }

    /** Имя места по умолчанию; пустая строка = проверять на месте, без телепорта. */
    public String defaultRoomName() {
        return rooms.getString("default", "");
    }

    public void setDefaultRoom(String name) {
        rooms.set("default", name == null ? "" : name.toLowerCase(Locale.ROOT));
        saveRooms();
    }

    public void setRoom(String name, Location l) {
        String n = name.toLowerCase(Locale.ROOT);
        rooms.set("rooms." + n + ".world", l.getWorld().getName());
        rooms.set("rooms." + n + ".x", l.getX());
        rooms.set("rooms." + n + ".y", l.getY());
        rooms.set("rooms." + n + ".z", l.getZ());
        rooms.set("rooms." + n + ".yaw", (double) l.getYaw());
        rooms.set("rooms." + n + ".pitch", (double) l.getPitch());
        if (defaultRoomName().isEmpty()) rooms.set("default", n);   // первое место становится основным
        saveRooms();
    }

    public boolean deleteRoom(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (!roomExists(n)) return false;
        rooms.set("rooms." + n, null);
        if (n.equals(defaultRoomName())) rooms.set("default", "");
        saveRooms();
        return true;
    }

    public String nextRoomName() {
        for (int i = 1; i < 1000; i++) {
            if (!roomExists("room" + i)) return "room" + i;
        }
        return "room" + System.currentTimeMillis();
    }

    /** Перенести проверяемого (и модератора) в другое место прямо во время проверки. */
    public Component moveToRoom(CheckSession s, String name) {
        Location l = room(name);
        if (l == null) return plugin.msg("room-not-found", "%room%", String.valueOf(name));
        teleportBoth(s, l);
        s.room = name.toLowerCase(Locale.ROOT);
        return null;
    }

    /** Вернуть проверяемого (и модератора) туда, где игрока вызвали на проверку. */
    public void moveToOrigin(CheckSession s) {
        if (s.suspectOrigin != null) teleportBoth(s, s.suspectOrigin);
        s.room = "";
    }

    private void teleportBoth(CheckSession s, Location l) {
        Player sp = Bukkit.getPlayer(s.suspect);
        Player mod = Bukkit.getPlayer(s.moderator);
        if (sp != null) sp.teleport(l);
        if (mod != null && plugin.getConfig().getBoolean("teleport-moderator", true)) {
            if (s.moderatorOrigin == null) s.moderatorOrigin = mod.getLocation().clone();
            mod.teleport(l);
        }
    }

    // ---------------- старт ----------------

    public Component start(Player mod, Player target) {
        return start(mod, target, null);
    }

    /**
     * @param roomName имя места или null (тогда место по умолчанию)
     * @return null при успехе, иначе сообщение об ошибке.
     */
    public Component start(Player mod, Player target, String roomName) {
        if (target.getUniqueId().equals(mod.getUniqueId())) return plugin.msg("self");
        if (target.hasPermission("sparkcheck.bypass")) return plugin.msg("bypass", "%player%", target.getName());
        if (sessions.containsKey(target.getUniqueId())) {
            return plugin.msg("already-checked", "%player%", target.getName());
        }
        if (sessions.containsKey(mod.getUniqueId())) return plugin.msg("moderator-checked");
        if (target.isDead() || !target.isOnline()) return plugin.msg("player-not-found");
        if (roomName != null && !roomExists(roomName)) return plugin.msg("room-not-found", "%room%", roomName);

        FileConfiguration c = plugin.getConfig();
        long total = Math.max(1, c.getLong("check-time-minutes", 5)) * 60_000L;
        CheckSession s = new CheckSession(target, mod, total);
        s.suspectOrigin = target.getLocation().clone();

        String rn = roomName != null ? roomName.toLowerCase(Locale.ROOT) : defaultRoomName();
        Location room = rn.isEmpty() ? null : room(rn);
        if (room != null) {
            s.room = rn;
            target.teleport(room);
            if (c.getBoolean("teleport-moderator", true)) {
                s.moderatorOrigin = mod.getLocation().clone();
                mod.teleport(room);
            }
        }

        s.bar = BossBar.bossBar(plugin.raw("bossbar", "%time%", Util.time(total)), 1f,
                BossBar.Color.RED, BossBar.Overlay.PROGRESS);
        target.showBossBar(s.bar);
        target.showTitle(Title.title(plugin.raw("started-title"), plugin.raw("started-subtitle"),
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(4), Duration.ofMillis(500))));
        target.playSound(target.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1f);
        sendInstruction(s, target);

        sessions.put(s.suspect, s);
        mod.sendMessage(plugin.msg("started-mod", "%player%", target.getName(), "%time%", Util.time(total)));

        if (c.getBoolean("notify-staff", true)) {
            Component note = plugin.msg("staff-started", "%moderator%", mod.getName(), "%player%", target.getName());
            for (Player o : Bukkit.getOnlinePlayers()) {
                if (o.hasPermission("sparkcheck.notify") && !o.getUniqueId().equals(mod.getUniqueId())) {
                    o.sendMessage(note);
                }
            }
        }
        return null;
    }

    public void sendInstruction(CheckSession s, Player target) {
        for (Component line : plugin.list("instruction", "%moderator%", s.moderatorName,
                "%time%", Util.time(Math.max(0, s.left())))) {
            target.sendMessage(line);
        }
    }

    // ---------------- признание ----------------

    /**
     * Игрок вводит /confess. Первый вызов - предупреждение, /confess confirm
     * в течение confirm-seconds - признание и наказание.
     */
    public void confess(Player p, boolean confirm) {
        CheckSession s = get(p.getUniqueId());
        if (s == null) {
            p.sendMessage(plugin.msg("confess-not-checked"));
            return;
        }
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("confess.enabled", true)) {
            p.sendMessage(plugin.msg("confess-disabled"));
            return;
        }
        long window = Math.max(5, c.getInt("confess.confirm-seconds", 15)) * 1000L;
        long now = System.currentTimeMillis();
        boolean pending = s.confessAt != 0 && now - s.confessAt <= window;
        if (!(confirm && pending)) {
            s.confessAt = now;
            p.sendMessage(plugin.msg("confess-warn", "%seconds%", String.valueOf(window / 1000)));
            Player mod = Bukkit.getPlayer(s.moderator);
            if (mod != null) mod.sendMessage(plugin.msg("confess-mod-notice", "%player%", s.suspectName));
            return;
        }
        s.confessAt = 0;
        finish(s, Verdict.CONFESSED, s.suspectName);
    }

    // ---------------- завершение ----------------

    public void finish(CheckSession s, Verdict v, String by) {
        if (sessions.remove(s.suspect) == null) return;      // уже завершена
        FileConfiguration c = plugin.getConfig();
        Player sp = Bukkit.getPlayer(s.suspect);
        Player mod = Bukkit.getPlayer(s.moderator);

        if (sp != null) {
            sp.hideBossBar(s.bar);
            if (v != Verdict.QUIT && c.getBoolean("return-after", true) && s.suspectOrigin != null) {
                sp.teleport(s.suspectOrigin);
            }
            if (v == Verdict.CLEAN) sp.sendMessage(plugin.msg("finished-clean"));
            else if (v == Verdict.CANCELLED) sp.sendMessage(plugin.msg("finished-cancelled"));
        }
        if (mod != null && s.moderatorOrigin != null && sessionsOf(s.moderator).isEmpty()) {
            mod.teleport(s.moderatorOrigin);
        }

        long durationSec = Math.max(0, (System.currentTimeMillis() - s.start) / 1000);
        history.add(new HistoryEntry(s.suspectName, s.moderatorName, v,
                System.currentTimeMillis(), durationSec, s.contact == null ? "" : s.contact));
        while (history.size() > MAX_HISTORY) history.remove(0);
        historyDirty = true;

        if (mod != null) {
            mod.sendMessage(plugin.msg("finished-mod", "%player%", s.suspectName, "%verdict%", v.title));
        }
        if (c.getBoolean("broadcast", true) && plugin.hasMessage("broadcast-" + v.key)) {
            Bukkit.broadcast(plugin.raw("broadcast-" + v.key, "%player%", s.suspectName,
                    "%moderator%", s.moderatorName));
        }

        for (String raw : c.getStringList("commands." + v.key)) {
            String cmd = raw.replace("%player%", s.suspectName).replace("%moderator%", s.moderatorName).trim();
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            if (!cmd.isEmpty()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        }

        if (s.reportId != 0) plugin.reports().autoClose(s.reportId, v);   // итог проверки закрывает репорт
    }

    public void shutdown() {
        for (CheckSession s : all()) finish(s, Verdict.CANCELLED, "перезагрузка плагина");
    }

    // ---------------- таймер ----------------

    public void startTimer() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    private void tick() {
        if (sessions.isEmpty()) return;
        FileConfiguration c = plugin.getConfig();
        boolean punish = "punish".equalsIgnoreCase(c.getString("timeout-action", "punish"));
        long reminder = c.getInt("reminder-seconds", 30) * 1000L;
        long now = System.currentTimeMillis();

        for (CheckSession s : all()) {
            long left = s.end - now;
            if (left <= 0) {
                if (punish) {
                    finish(s, Verdict.TIMEOUT, "система");
                    continue;
                }
                if (!s.timeoutNotified) {
                    s.timeoutNotified = true;
                    Player mod = Bukkit.getPlayer(s.moderator);
                    if (mod != null) mod.sendMessage(plugin.msg("timeout-notify", "%player%", s.suspectName));
                }
                left = 0;
            }
            Player sp = Bukkit.getPlayer(s.suspect);
            if (sp == null) continue;
            s.bar.name(plugin.raw("bossbar", "%time%", Util.time(left)));
            s.bar.progress((float) Math.max(0.0, Math.min(1.0, left / (double) s.total)));
            if (reminder > 0 && now - s.lastReminder >= reminder) {
                s.lastReminder = now;
                sendInstruction(s, sp);
            }
        }
    }

    // ---------------- личные сообщения проверки ----------------

    private void ping(Player p) {
        if (plugin.getConfig().getBoolean("pm-sound", true)) {
            p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.4f);
        }
    }

    /** Проверяемый пишет в чат -> это личное сообщение его проверяющему. */
    public void suspectSaid(CheckSession s, String text) {
        if (s.contact == null && !text.isBlank()) {
            s.contact = Util.clean(text.length() > 120 ? text.substring(0, 120) : text);
        }
        Player sp = Bukkit.getPlayer(s.suspect);
        Player mod = Bukkit.getPlayer(s.moderator);
        if (sp != null) sp.sendMessage(plugin.chat("pm-self", s.suspectName, s.moderatorName, text));
        if (mod != null) {
            mod.sendMessage(plugin.chat("pm-in", s.suspectName, s.moderatorName, text));
            ping(mod);
        }
        Bukkit.getConsoleSender().sendMessage(plugin.chat("pm-self", s.suspectName, s.moderatorName, text));
    }

    /** Проверяющий пишет в чат -> личное сообщение проверяемому. */
    public void moderatorSaid(Player mod, List<CheckSession> mine, String text) {
        for (CheckSession s : mine) {
            mod.sendMessage(plugin.chat("pm-self", mod.getName(), s.suspectName, text));
            Player sp = Bukkit.getPlayer(s.suspect);
            if (sp != null) {
                sp.sendMessage(plugin.chat("pm-in", mod.getName(), s.suspectName, text));
                ping(sp);
            }
            Bukkit.getConsoleSender().sendMessage(plugin.chat("pm-self", mod.getName(), s.suspectName, text));
        }
    }

    // ---------------- история ----------------

    private void loadHistory() {
        if (!historyFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(historyFile);
        for (Map<?, ?> m : y.getMapList("entries")) {
            try {
                history.add(new HistoryEntry(str(m.get("suspect")), str(m.get("moderator")),
                        Verdict.valueOf(str(m.get("verdict"))), num(m.get("time")),
                        num(m.get("duration")), str(m.get("contact"))));
            } catch (IllegalArgumentException ignored) {
                // повреждённая запись - пропускаем
            }
        }
    }

    private boolean historyDirty;
    private final Object fileLock = new Object();

    /** Записать историю на диск, если она менялась. async=true - запись в отдельном потоке. */
    public void flush(boolean async) {
        if (!historyDirty) return;
        historyDirty = false;
        YamlConfiguration y = new YamlConfiguration();
        List<Map<String, Object>> list = new ArrayList<>();
        for (HistoryEntry h : history) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("suspect", h.suspect());
            m.put("moderator", h.moderator());
            m.put("verdict", h.verdict().name());
            m.put("time", h.time());
            m.put("duration", h.durationSec());
            m.put("contact", h.contact());
            list.add(m);
        }
        y.set("entries", list);
        String data = y.saveToString();
        Runnable write = () -> {
            synchronized (fileLock) {
                try {
                    Files.createDirectories(historyFile.getParentFile().toPath());
                    Files.writeString(historyFile.toPath(), data, StandardCharsets.UTF_8);
                } catch (IOException e) {
                    plugin.getLogger().warning("Не удалось сохранить history.yml: " + e.getMessage());
                }
            }
        };
        if (async && plugin.isEnabled()) Bukkit.getScheduler().runTaskAsynchronously(plugin, write);
        else write.run();
    }

    private static String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    private static long num(Object o) {
        return o instanceof Number n ? n.longValue() : 0L;
    }
}
