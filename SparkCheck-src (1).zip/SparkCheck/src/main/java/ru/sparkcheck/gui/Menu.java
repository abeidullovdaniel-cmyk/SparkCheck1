package ru.sparkcheck.gui;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import ru.sparkcheck.SparkCheck;

/** Базовый класс всех меню. Инвентарь создаётся в наследнике. */
public abstract class Menu implements InventoryHolder {
    protected final SparkCheck plugin;
    protected Inventory inv;

    protected Menu(SparkCheck plugin) {
        this.plugin = plugin;
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }

    public abstract void click(Player p, int slot, ClickType type);

    public void open(Player p) {
        p.openInventory(inv);
    }
}
