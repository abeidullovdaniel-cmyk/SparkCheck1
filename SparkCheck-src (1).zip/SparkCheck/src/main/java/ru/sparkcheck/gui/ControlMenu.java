package ru.sparkcheck.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import ru.sparkcheck.CheckSession;
import ru.sparkcheck.SparkCheck;
import ru.sparkcheck.Util;
import ru.sparkcheck.Verdict;

import java.util.List;

/** Управление одной проверкой: вердикты, время, место, телепорт, заморозка, инвентарь. */
public final class ControlMenu extends Menu {
    private final CheckSession s;

    public ControlMenu(SparkCheck plugin, CheckSession s) {
        super(plugin);
        this.s = s;
        inv = Bukkit.createInventory(this, 27, Util.c("&8Проверка: &c" + s.suspectName));
        for (int i = 0; i < 27; i++) inv.setItem(i, Util.filler());

        Player t = Bukkit.getPlayer(s.suspect);
        inv.setItem(4, Util.head(s.suspect, "&e" + s.suspectName,
                "&7Модератор: &f" + s.moderatorName,
                "&7Осталось: &f" + Util.time(s.left()),
                "&7Контакт: &f" + (s.contact == null ? "&8ещё не отправил" : s.contact),
                "&7Пинг: &f" + (t == null ? "—" : t.getPing() + " мс"),
                "&7Место: &f" + (s.room.isEmpty() ? "на месте вызова" : s.room),
                "&7Заморозка: " + (s.frozen ? "&aвключена" : "&cвыключена")));

        inv.setItem(10, Util.item(Material.LIME_CONCRETE, "&a&lЧист",
                "&7Завершить проверку, игрок свободен", "&7Выполнятся команды из commands.clean"));
        inv.setItem(12, Util.item(Material.RED_CONCRETE, "&c&lЧиты",
                "&7Найдены читы", "&cБудут выполнены команды наказания", "&7(потребуется подтверждение)"));
        inv.setItem(14, Util.item(Material.ORANGE_CONCRETE, "&6&lОтказ от проверки",
                "&7Игрок отказался или не вышел на связь", "&cБудут выполнены команды наказания",
                "&7(потребуется подтверждение)"));
        inv.setItem(16, Util.item(Material.BARRIER, "&7Отменить проверку",
                "&7Без наказания, игрок освобождается"));

        inv.setItem(19, Util.item(Material.CLOCK, "&bДобавить время",
                "&aЛКМ &7- +5 минут", "&aПКМ &7- +1 минута"));
        inv.setItem(20, Util.item(Material.ENDER_PEARL, "&dТелепорт к игроку"));
        inv.setItem(21, Util.item(s.frozen ? Material.PACKED_ICE : Material.ICE,
                "&bЗаморозка: " + (s.frozen ? "&aвкл" : "&cвыкл"), "&7Нажмите, чтобы переключить"));
        inv.setItem(22, Util.item(Material.PAPER, "&eОтправить инструкцию ещё раз"));
        inv.setItem(23, Util.item(Material.CHEST, "&6Посмотреть инвентарь", "&7Только просмотр"));
        inv.setItem(24, Util.item(Material.COMPASS, "&dСменить место проверки",
                "&7Сейчас: &f" + (s.room.isEmpty() ? "на месте вызова" : s.room),
                "&7Перенесёт игрока и вас"));
        inv.setItem(26, Util.item(Material.ARROW, "&e← К списку проверок"));
    }

    @Override
    public void click(Player p, int slot, ClickType type) {
        if (plugin.manager().get(s.suspect) == null) {            // уже завершена
            new ActiveMenu(plugin).open(p);
            return;
        }
        Player t = Bukkit.getPlayer(s.suspect);
        switch (slot) {
            case 10 -> {
                if (!plugin.has(p, "sparkcheck.verdict.clean")) return;
                p.closeInventory();
                plugin.manager().finish(s, Verdict.CLEAN, p.getName());
            }
            case 12 -> {
                if (!plugin.has(p, "sparkcheck.verdict.punish")) return;
                new ConfirmMenu(plugin, "&cВердикт: ЧИТЫ",
                        List.of("&7Игрок: &f" + s.suspectName, "&7Будут выполнены команды наказания."),
                        () -> plugin.manager().finish(s, Verdict.CHEATS, p.getName()),
                        () -> new ControlMenu(plugin, s)).open(p);
            }
            case 14 -> {
                if (!plugin.has(p, "sparkcheck.verdict.punish")) return;
                new ConfirmMenu(plugin, "&6Вердикт: ОТКАЗ",
                        List.of("&7Игрок: &f" + s.suspectName, "&7Будут выполнены команды наказания."),
                        () -> plugin.manager().finish(s, Verdict.REFUSED, p.getName()),
                        () -> new ControlMenu(plugin, s)).open(p);
            }
            case 16 -> {
                if (!plugin.has(p, "sparkcheck.verdict.cancel")) return;
                p.closeInventory();
                plugin.manager().finish(s, Verdict.CANCELLED, p.getName());
            }
            case 19 -> {
                s.addTime(type.isRightClick() ? 60_000L : 300_000L);
                new ControlMenu(plugin, s).open(p);
            }
            case 20 -> {
                if (t != null) p.teleport(t.getLocation());
                else p.sendMessage(plugin.msg("player-not-found"));
            }
            case 21 -> {
                s.frozen = !s.frozen;
                new ControlMenu(plugin, s).open(p);
            }
            case 22 -> {
                if (t != null) plugin.manager().sendInstruction(s, t);
                p.sendMessage(plugin.msg("instruction-sent"));
            }
            case 23 -> {
                if (!plugin.has(p, "sparkcheck.inventory")) return;
                if (t == null) {
                    p.sendMessage(plugin.msg("player-not-found"));
                } else {
                    p.openInventory(t.getInventory());
                    plugin.startViewing(p);          // после openInventory: закрытие прошлого меню сбрасывает флаг
                }
            }
            case 24 -> {
                if (plugin.has(p, "sparkcheck.room.move")) new RoomsMenu(plugin, s).open(p);
            }
            case 26 -> new ActiveMenu(plugin).open(p);
            default -> {
            }
        }
    }
}
