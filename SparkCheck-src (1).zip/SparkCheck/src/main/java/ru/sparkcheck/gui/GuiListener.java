package ru.sparkcheck.gui;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;
import ru.sparkcheck.SparkCheck;

public final class GuiListener implements Listener {
    private final SparkCheck plugin;

    public GuiListener(SparkCheck plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        InventoryHolder holder = e.getInventory().getHolder(false);
        if (holder instanceof Menu m) {
            e.setCancelled(true);
            if (e.getClickedInventory() != e.getView().getTopInventory()) return;
            m.click(p, e.getSlot(), e.getClick());
            return;
        }
        if (plugin.isViewing(p)) e.setCancelled(true);   // просмотр чужого инвентаря - только смотреть
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getInventory().getHolder(false) instanceof Menu || plugin.isViewing(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (e.getPlayer() instanceof Player p) plugin.stopViewing(p);
    }
}
