package ru.sparkcheck.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import ru.sparkcheck.CheckSession;
import ru.sparkcheck.SparkCheck;
import ru.sparkcheck.Util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Список идущих проверок. */
public final class ActiveMenu extends Menu {
    private final List<CheckSession> sessions = new ArrayList<>();

    public ActiveMenu(SparkCheck plugin) {
        super(plugin);
        sessions.addAll(plugin.manager().all());
        sessions.sort(Comparator.comparingLong(s -> s.start));
        inv = Bukkit.createInventory(this, 54, Util.c("&8Активные проверки"));
        for (int i = 0; i < 45 && i < sessions.size(); i++) {
            CheckSession s = sessions.get(i);
            inv.setItem(i, Util.head(s.suspect, "&e" + s.suspectName,
                    "&7Модератор: &f" + s.moderatorName,
                    "&7Осталось: &f" + Util.time(s.left()),
                    "&7Контакт: &f" + (s.contact == null ? "&8ещё не отправил" : s.contact),
                    "&aЛКМ &7- управление"));
        }
        for (int i = 45; i < 54; i++) inv.setItem(i, Util.filler());
        inv.setItem(49, Util.item(Material.ARROW, "&e← К списку игроков"));
    }

    @Override
    public void click(Player p, int slot, ClickType type) {
        if (slot == 49) {
            new MainMenu(plugin, p, 0).open(p);
            return;
        }
        if (slot >= 45 || slot >= sessions.size()) return;
        CheckSession s = sessions.get(slot);
        if (plugin.manager().get(s.suspect) == null) {          // проверка уже завершилась
            new ActiveMenu(plugin).open(p);
            return;
        }
        new ControlMenu(plugin, s).open(p);
    }
}
