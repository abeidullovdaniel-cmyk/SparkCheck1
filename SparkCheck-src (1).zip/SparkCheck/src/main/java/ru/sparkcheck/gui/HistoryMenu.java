package ru.sparkcheck.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import ru.sparkcheck.CheckManager;
import ru.sparkcheck.SparkCheck;
import ru.sparkcheck.Util;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Последние вердикты (хранятся в history.yml). */
public final class HistoryMenu extends Menu {
    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(ZoneId.systemDefault());

    public HistoryMenu(SparkCheck plugin) {
        super(plugin);
        inv = Bukkit.createInventory(this, 54, Util.c("&8История проверок"));
        List<CheckManager.HistoryEntry> list = new ArrayList<>(plugin.manager().history());
        Collections.reverse(list);                       // новые сверху
        for (int i = 0; i < 45 && i < list.size(); i++) {
            CheckManager.HistoryEntry h = list.get(i);
            Material m = switch (h.verdict()) {
                case CLEAN -> Material.LIME_DYE;
                case CHEATS, CONFESSED -> Material.RED_DYE;
                case REFUSED, TIMEOUT, QUIT -> Material.ORANGE_DYE;
                default -> Material.GRAY_DYE;
            };
            inv.setItem(i, Util.item(m, "&f" + h.suspect(),
                    "&7Вердикт: &e" + h.verdict().title,
                    "&7Модератор: &f" + h.moderator(),
                    "&7Дата: &f" + FMT.format(Instant.ofEpochMilli(h.time())),
                    "&7Длительность: &f" + Util.time(h.durationSec() * 1000L),
                    "&7Контакт: &f" + (h.contact().isEmpty() ? "&8нет" : h.contact())));
        }
        for (int i = 45; i < 54; i++) inv.setItem(i, Util.filler());
        inv.setItem(49, Util.item(Material.ARROW, "&e← К списку игроков"));
    }

    @Override
    public void click(Player p, int slot, ClickType type) {
        if (slot == 49) new MainMenu(plugin, p, 0).open(p);
    }
}
