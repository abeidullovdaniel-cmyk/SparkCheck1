package ru.sparkcheck.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import ru.sparkcheck.ReportReason;
import ru.sparkcheck.SparkCheck;
import ru.sparkcheck.Util;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Меню игрока: выбор причины жалобы. Открывается командой /report <ник>. */
public final class ReportReasonMenu extends Menu {
    private static final int[] SLOTS = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};

    private final UUID target;
    private final String targetName;
    private final List<ReportReason> reasons;

    public ReportReasonMenu(SparkCheck plugin, UUID target, String targetName) {
        super(plugin);
        this.target = target;
        this.targetName = targetName;
        this.reasons = plugin.reasons();
        inv = Bukkit.createInventory(this, 36, Util.c("&8Репорт на &c" + targetName));
        for (int i = 0; i < 36; i++) inv.setItem(i, Util.filler());

        inv.setItem(4, Util.head(target, "&e" + targetName, "&7Выберите причину жалобы"));
        for (int i = 0; i < reasons.size() && i < SLOTS.length; i++) {
            ReportReason r = reasons.get(i);
            List<String> lore = new ArrayList<>(r.description());
            lore.add(" ");
            lore.add("&aНажмите, чтобы отправить репорт");
            inv.setItem(SLOTS[i], Util.item(r.material(), r.name(), lore.toArray(new String[0])));
        }
        inv.setItem(31, Util.item(Material.BARRIER, "&cОтмена"));
    }

    @Override
    public void click(Player p, int slot, ClickType type) {
        if (slot == 31) {
            p.closeInventory();
            return;
        }
        for (int i = 0; i < reasons.size() && i < SLOTS.length; i++) {
            if (SLOTS[i] != slot) continue;
            p.closeInventory();
            Component err = plugin.reports().submit(p, target, targetName, reasons.get(i).key());
            if (err != null) p.sendMessage(err);
            return;
        }
    }
}
