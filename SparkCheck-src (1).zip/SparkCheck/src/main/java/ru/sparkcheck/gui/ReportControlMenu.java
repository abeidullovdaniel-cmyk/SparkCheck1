package ru.sparkcheck.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import ru.sparkcheck.CheckSession;
import ru.sparkcheck.Report;
import ru.sparkcheck.SparkCheck;
import ru.sparkcheck.Util;

/** Управление взятым репортом: проверка, телепорт, подтвердить, отклонить, вернуть в общий список. */
public final class ReportControlMenu extends Menu {
    private final Report r;

    public ReportControlMenu(SparkCheck plugin, Report r) {
        super(plugin);
        this.r = r;
        inv = Bukkit.createInventory(this, 27, Util.c("&8Репорт #" + r.id + " на &c" + r.targetName));
        for (int i = 0; i < 27; i++) inv.setItem(i, Util.filler());

        Player t = Bukkit.getPlayer(r.target);
        inv.setItem(4, Util.head(r.target, "&c#" + r.id + " &f" + r.targetName,
                "&7Кто пожаловался: &f" + r.reporterName,
                "&7Причина: &e" + r.reasonTitle,
                "&7Время: &f" + Util.stamp(r.time) + " &8(" + Util.ago(System.currentTimeMillis() - r.time) + " назад)",
                "&7Статус: &f" + r.status.title + (r.moderatorName.isEmpty() ? "" : " &8(" + r.moderatorName + ")"),
                "&7Жалоб на игрока: &f" + plugin.reports().activeOn(r.target),
                "&7Игрок: " + (t != null ? "&aонлайн" : "&cоффлайн")));

        inv.setItem(10, Util.item(Material.SPYGLASS, "&b&lВызвать на проверку",
                "&7Начнёт проверку на читы", "&7Итог проверки закроет репорт сам"));
        inv.setItem(11, Util.item(Material.ENDER_PEARL, "&dТелепорт к игроку"));
        inv.setItem(14, Util.item(Material.LIME_CONCRETE, "&a&lПодтвердить репорт",
                "&7Нарушение подтвердилось", "&7Жалобщик получит уведомление"));
        inv.setItem(15, Util.item(Material.RED_CONCRETE, "&c&lОтклонить репорт",
                "&7Нарушение не подтвердилось", "&7Жалобщик получит уведомление"));
        inv.setItem(16, Util.item(Material.BARRIER, "&7Вернуть в общий список",
                "&7Репорт снова увидят все модераторы"));
        inv.setItem(26, Util.item(Material.ARROW, "&e← К репортам"));
    }

    @Override
    public void click(Player p, int slot, ClickType type) {
        if (slot == 26) {
            new ReportsMenu(plugin, p, true, 0).open(p);
            return;
        }
        if (r.status != Report.Status.TAKEN) {                       // уже закрыт или возвращён
            new ReportsMenu(plugin, p, true, 0).open(p);
            return;
        }
        boolean own = p.getUniqueId().equals(r.moderator);
        if (!own && !p.hasPermission("sparkcheck.reports.manage")) {
            p.sendMessage(plugin.msg("report-not-yours", "%moderator%", r.moderatorName));
            return;
        }
        switch (slot) {
            case 10 -> {
                Player t = Bukkit.getPlayer(r.target);
                if (t == null) {
                    p.sendMessage(plugin.msg("report-target-offline"));
                    return;
                }
                Component err = plugin.manager().start(p, t, null);
                if (err != null) {
                    p.sendMessage(err);
                    return;
                }
                CheckSession s = plugin.manager().get(t.getUniqueId());
                if (s != null) {
                    s.reportId = r.id;                              // итог проверки закроет репорт
                    new ControlMenu(plugin, s).open(p);
                }
            }
            case 11 -> {
                Player t = Bukkit.getPlayer(r.target);
                if (t != null) p.teleport(t.getLocation());
                else p.sendMessage(plugin.msg("report-target-offline"));
            }
            case 14 -> {
                p.closeInventory();
                plugin.reports().close(r, Report.Status.CONFIRMED);
            }
            case 15 -> {
                p.closeInventory();
                plugin.reports().close(r, Report.Status.REJECTED);
            }
            case 16 -> {
                plugin.reports().release(r);
                p.sendMessage(plugin.msg("report-released", "%id%", String.valueOf(r.id)));
                new ReportsMenu(plugin, p, false, 0).open(p);
            }
            default -> {
            }
        }
    }
}
