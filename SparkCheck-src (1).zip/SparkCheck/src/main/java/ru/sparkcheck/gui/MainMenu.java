package ru.sparkcheck.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import ru.sparkcheck.CheckSession;
import ru.sparkcheck.SparkCheck;
import ru.sparkcheck.Util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Главное меню: список игроков онлайн, клик = вызвать на проверку. */
public final class MainMenu extends Menu {
    private static final int PAGE = 45;
    private final List<Player> players = new ArrayList<>();
    private final int page;
    private final int pages;

    public MainMenu(SparkCheck plugin, Player viewer, int page) {
        super(plugin);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getUniqueId().equals(viewer.getUniqueId())) continue;
            if (p.hasPermission("sparkcheck.bypass")) continue;
            players.add(p);
        }
        players.sort(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER));
        this.pages = Math.max(1, (players.size() + PAGE - 1) / PAGE);
        this.page = Math.max(0, Math.min(page, pages - 1));
        inv = Bukkit.createInventory(this, 54, Util.c("&8Проверка на читы &7(" + (this.page + 1) + "/" + pages + ")"));
        build();
    }

    private void build() {
        for (int i = 0; i < PAGE; i++) {
            int idx = page * PAGE + i;
            if (idx >= players.size()) break;
            Player t = players.get(idx);
            CheckSession s = plugin.manager().get(t.getUniqueId());
            if (s != null) {
                inv.setItem(i, Util.head(t.getUniqueId(), "&e" + t.getName(),
                        "&7Пинг: &f" + t.getPing() + " мс",
                        "&cУже на проверке &7(" + Util.time(s.left()) + ")",
                        "&aЛКМ &7- открыть управление"));
            } else {
                inv.setItem(i, Util.head(t.getUniqueId(), "&f" + t.getName(),
                        "&7Пинг: &f" + t.getPing() + " мс",
                        "&7Мир: &f" + t.getWorld().getName(),
                        "&aЛКМ &7- вызвать на проверку"));
            }
        }
        for (int i = 45; i < 54; i++) inv.setItem(i, Util.filler());
        inv.setItem(45, Util.item(Material.ARROW, "&e← Назад", "&7Предыдущая страница"));
        inv.setItem(46, Util.item(Material.ENDER_PEARL, "&dМеста проверки", "&7Где проходят проверки"));
        inv.setItem(47, Util.item(Material.COMPASS, "&bАктивные проверки",
                "&7Сейчас идёт: &f" + plugin.manager().all().size()));
        inv.setItem(48, Util.item(Material.WRITABLE_BOOK, "&cРепорты на игроков",
                "&7Открытых репортов: &f" + plugin.reports().openCount(),
                "&7Взятый вами репорт пропадает у других"));
        inv.setItem(49, Util.item(Material.BARRIER, "&cЗакрыть"));
        inv.setItem(51, Util.item(Material.BOOK, "&6История проверок", "&7Последние вердикты"));
        inv.setItem(53, Util.item(Material.ARROW, "&eВперёд →", "&7Следующая страница"));
    }

    @Override
    public void click(Player p, int slot, ClickType type) {
        if (slot < PAGE) {
            int idx = page * PAGE + slot;
            if (idx >= players.size()) return;
            Player t = players.get(idx);
            if (!t.isOnline()) {
                p.sendMessage(plugin.msg("player-not-found"));
                return;
            }
            CheckSession s = plugin.manager().get(t.getUniqueId());
            if (s == null) {
                Component err = plugin.manager().start(p, t);
                if (err != null) {
                    p.sendMessage(err);
                    return;
                }
                s = plugin.manager().get(t.getUniqueId());
            }
            if (s != null) new ControlMenu(plugin, s).open(p);
            return;
        }
        switch (slot) {
            case 45 -> new MainMenu(plugin, p, page - 1).open(p);
            case 53 -> new MainMenu(plugin, p, page + 1).open(p);
            case 47 -> new ActiveMenu(plugin).open(p);
            case 49 -> p.closeInventory();
            case 48 -> {
                if (plugin.has(p, "sparkcheck.reports")) new ReportsMenu(plugin, p, false, 0).open(p);
            }
            case 46 -> {
                if (plugin.has(p, "sparkcheck.room")) new RoomsMenu(plugin, null).open(p);
            }
            case 51 -> {
                if (plugin.has(p, "sparkcheck.history")) new HistoryMenu(plugin).open(p);
            }
            default -> {
            }
        }
    }
}
