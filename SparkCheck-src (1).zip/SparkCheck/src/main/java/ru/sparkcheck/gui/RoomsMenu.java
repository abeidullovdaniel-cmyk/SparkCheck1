package ru.sparkcheck.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import ru.sparkcheck.CheckSession;
import ru.sparkcheck.SparkCheck;
import ru.sparkcheck.Util;

import java.util.List;

/**
 * Места проверки. pick == null: управление (по умолчанию / телепорт / удаление / добавить).
 * pick != null: выбор места, куда перенести игрока во время проверки.
 */
public final class RoomsMenu extends Menu {
    private final CheckSession pick;
    private final List<String> names;

    public RoomsMenu(SparkCheck plugin, CheckSession pick) {
        super(plugin);
        this.pick = pick;
        this.names = plugin.manager().roomNames();
        String def = plugin.manager().defaultRoomName();
        inv = Bukkit.createInventory(this, 54,
                Util.c(pick == null ? "&8Места проверки" : "&8Сменить место: &c" + pick.suspectName));

        for (int i = 0; i < 45 && i < names.size(); i++) {
            String n = names.get(i);
            Location l = plugin.manager().room(n);
            boolean isDef = n.equals(def);
            String where = l == null ? "&cмир не найден"
                    : "&7" + l.getWorld().getName() + " &f" + l.getBlockX() + " " + l.getBlockY() + " " + l.getBlockZ();
            if (pick == null) {
                inv.setItem(i, Util.item(isDef ? Material.ENDER_EYE : Material.ENDER_PEARL,
                        "&e" + n + (isDef ? " &a(по умолчанию)" : ""), where,
                        "&aЛКМ &7- сделать местом по умолчанию",
                        "&aПКМ &7- телепортироваться",
                        "&cShift+ПКМ &7- удалить"));
            } else {
                inv.setItem(i, Util.item(Material.ENDER_PEARL, "&e" + n, where,
                        "&aЛКМ &7- перенести сюда игрока и вас"));
            }
        }
        for (int i = 45; i < 54; i++) inv.setItem(i, Util.filler());
        inv.setItem(45, Util.item(Material.ARROW, "&e← Назад"));
        if (pick == null) {
            inv.setItem(47, Util.item(Material.EMERALD, "&aДобавить текущее место",
                    "&7Сохранит вашу позицию как новое место", "&7(название: " + plugin.manager().nextRoomName() + ")"));
            inv.setItem(49, Util.item(def.isEmpty() ? Material.LIME_DYE : Material.GRAY_DYE,
                    "&bПроверять на месте (без телепорта)" + (def.isEmpty() ? " &a(включено)" : ""),
                    "&7Игрок остаётся там, где его вызвали"));
        } else {
            inv.setItem(49, Util.item(Material.COMPASS, "&bНа место, где игрока вызвали",
                    "&7Вернуть игрока и вас на исходную позицию"));
        }
        if (names.isEmpty()) {
            inv.setItem(22, Util.item(Material.BARRIER, "&cМест пока нет",
                    "&7Встаньте в нужное место и нажмите", "&7«Добавить текущее место»", "&7или /sparkcheck setroom <имя>"));
        }
    }

    @Override
    public void click(Player p, int slot, ClickType type) {
        if (slot == 45) {
            if (pick == null) new MainMenu(plugin, p, 0).open(p);
            else new ControlMenu(plugin, pick).open(p);
            return;
        }
        if (slot < 45) {
            if (slot >= names.size()) return;
            String n = names.get(slot);
            if (pick != null) {
                if (!plugin.has(p, "sparkcheck.room.move")) return;
                if (plugin.manager().get(pick.suspect) == null) {
                    p.closeInventory();
                    return;
                }
                Component err = plugin.manager().moveToRoom(pick, n);
                if (err != null) {
                    p.sendMessage(err);
                } else {
                    p.sendMessage(plugin.msg("moved-room", "%room%", n));
                    new ControlMenu(plugin, pick).open(p);
                }
                return;
            }
            if (!plugin.has(p, "sparkcheck.room")) return;
            if (type.isShiftClick() && type.isRightClick()) {
                new ConfirmMenu(plugin, "&cУдалить место " + n,
                        List.of("&7Место будет удалено без возможности восстановления."),
                        () -> {
                            plugin.manager().deleteRoom(n);
                            p.sendMessage(plugin.msg("room-deleted", "%room%", n));
                        },
                        () -> new RoomsMenu(plugin, null)).open(p);
            } else if (type.isRightClick()) {
                Location l = plugin.manager().room(n);
                if (l != null) p.teleport(l);
                else p.sendMessage(plugin.msg("room-not-found", "%room%", n));
            } else {
                plugin.manager().setDefaultRoom(n);
                p.sendMessage(plugin.msg("room-default-set", "%room%", n));
                new RoomsMenu(plugin, null).open(p);
            }
            return;
        }
        if (pick != null) {
            if (slot == 49 && plugin.has(p, "sparkcheck.room.move")) {
                if (plugin.manager().get(pick.suspect) == null) {
                    p.closeInventory();
                    return;
                }
                plugin.manager().moveToOrigin(pick);
                p.sendMessage(plugin.msg("moved-origin"));
                new ControlMenu(plugin, pick).open(p);
            }
            return;
        }
        if (!plugin.has(p, "sparkcheck.room")) return;
        if (slot == 47) {
            String name = plugin.manager().nextRoomName();
            plugin.manager().setRoom(name, p.getLocation());
            p.sendMessage(plugin.msg("room-set", "%room%", name));
            new RoomsMenu(plugin, null).open(p);
        } else if (slot == 49) {
            plugin.manager().setDefaultRoom("");
            p.sendMessage(plugin.msg("room-default-none"));
            new RoomsMenu(plugin, null).open(p);
        }
    }
}
