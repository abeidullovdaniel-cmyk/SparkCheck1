package ru.sparkcheck.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import ru.sparkcheck.SparkCheck;
import ru.sparkcheck.Util;

import java.util.List;
import java.util.function.Supplier;

/** Подтверждение опасного действия (бан и т.п.). */
public final class ConfirmMenu extends Menu {
    private final Runnable yes;
    private final Supplier<Menu> no;

    public ConfirmMenu(SparkCheck plugin, String title, List<String> lore, Runnable yes, Supplier<Menu> no) {
        super(plugin);
        this.yes = yes;
        this.no = no;
        inv = Bukkit.createInventory(this, 27, Util.c(title));
        for (int i = 0; i < 27; i++) inv.setItem(i, Util.filler());
        inv.setItem(11, Util.item(Material.LIME_CONCRETE, "&a&lПодтвердить"));
        inv.setItem(15, Util.item(Material.RED_CONCRETE, "&c&lОтмена"));
        inv.setItem(13, Util.item(Material.PAPER, "&eВы уверены?", lore.toArray(new String[0])));
    }

    @Override
    public void click(Player p, int slot, ClickType type) {
        if (slot == 11) {
            p.closeInventory();
            yes.run();
        } else if (slot == 15) {
            no.get().open(p);
        }
    }
}
