package ru.sparkcheck.gui;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import ru.sparkcheck.Report;
import ru.sparkcheck.SparkCheck;
import ru.sparkcheck.Util;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Меню модератора: репорты на игроков. mine=false - свободные (общий список),
 * mine=true - те, что взял этот модератор. Взятый репорт исчезает из общего списка у всех.
 */
public final class ReportsMenu extends Menu {
    private static final int PAGE = 45;
    private final boolean mine;
    private final int page;
    private final int pages;
    private final List<Report> list;

    public ReportsMenu(SparkCheck plugin, Player viewer, boolean mine, int page) {
        super(plugin);
        this.mine = mine;
        this.list = mine ? plugin.reports().takenBy(viewer.getUniqueId()) : plugin.reports().open();
        this.pages = Math.max(1, (list.size() + PAGE - 1) / PAGE);
        this.page = Math.max(0, Math.min(page, pages - 1));
        inv = Bukkit.createInventory(this, 54, Util.c(
                (mine ? "&8Репорты: мои" : "&8Репорты: открытые") + " &7(" + list.size() + ")"));

        Map<UUID, Integer> counts = plugin.reports().activeCounts();
        for (int i = 0; i < PAGE; i++) {
            int idx = this.page * PAGE + i;
            if (idx >= list.size()) break;
            Report r = list.get(idx);
            Player t = Bukkit.getPlayer(r.target);
            long age = System.currentTimeMillis() - r.time;
            inv.setItem(i, Util.head(r.target, "&c#" + r.id + " &f" + r.targetName,
                    "&7Кто пожаловался: &f" + r.reporterName,
                    "&7На кого: &f" + r.targetName,
                    "&7Причина: &e" + r.reasonTitle,
                    "&7Время: &f" + Util.stamp(r.time) + " &8(" + Util.ago(age) + " назад)",
                    "&7Жалоб на игрока: &f" + counts.getOrDefault(r.target, 1),
                    "&7Игрок: " + (t != null ? "&aонлайн" : "&cоффлайн"),
                    mine ? "&aЛКМ &7- управление репортом" : "&aЛКМ &7- взять репорт на себя"));
        }

        for (int i = 45; i < 54; i++) inv.setItem(i, Util.filler());
        inv.setItem(45, Util.item(Material.ARROW, "&e← Назад", "&7Предыдущая страница"));
        if (mine) {
            inv.setItem(47, Util.item(Material.WRITABLE_BOOK, "&bПоказать открытые",
                    "&7Свободные репорты: &f" + plugin.reports().openCount()));
        } else {
            inv.setItem(47, Util.item(Material.BOOK, "&bПоказать мои",
                    "&7Репорты, которые вы взяли: &f" + plugin.reports().takenBy(viewer.getUniqueId()).size()));
        }
        inv.setItem(49, Util.item(Material.ARROW, "&e← К списку игроков"));
        inv.setItem(53, Util.item(Material.ARROW, "&eВперёд →", "&7Следующая страница"));
    }

    @Override
    public void click(Player p, int slot, ClickType type) {
        if (slot < PAGE) {
            int idx = page * PAGE + slot;
            if (idx >= list.size()) return;
            Report r = list.get(idx);
            if (mine) {
                if (r.status != Report.Status.TAKEN) {              // уже закрыт или возвращён
                    new ReportsMenu(plugin, p, true, page).open(p);
                    return;
                }
                new ReportControlMenu(plugin, r).open(p);
                return;
            }
            Component err = plugin.reports().take(r.id, p);
            if (err != null) {                                       // кто-то успел раньше
                p.sendMessage(err);
                new ReportsMenu(plugin, p, false, page).open(p);
                return;
            }
            new ReportControlMenu(plugin, r).open(p);
            return;
        }
        switch (slot) {
            case 45 -> new ReportsMenu(plugin, p, mine, page - 1).open(p);
            case 53 -> new ReportsMenu(plugin, p, mine, page + 1).open(p);
            case 47 -> new ReportsMenu(plugin, p, !mine, 0).open(p);
            case 49 -> new MainMenu(plugin, p, 0).open(p);
            default -> {
            }
        }
    }
}
