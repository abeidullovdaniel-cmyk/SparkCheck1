package ru.sparkcheck;

/** Итог проверки. key - ключ в разделе commands: конфига. */
public enum Verdict {
    CLEAN("Чист", "clean"),
    CHEATS("Читы", "cheats"),
    CONFESSED("Признание", "confess"),
    REFUSED("Отказ от проверки", "refused"),
    TIMEOUT("Время вышло", "timeout"),
    QUIT("Выход во время проверки", "quit"),
    CANCELLED("Проверка отменена", "cancelled");

    public final String title;
    public final String key;

    Verdict(String title, String key) {
        this.title = title;
        this.key = key;
    }
}
