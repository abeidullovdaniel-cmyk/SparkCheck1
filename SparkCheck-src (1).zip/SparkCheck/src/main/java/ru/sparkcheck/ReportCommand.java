package ru.sparkcheck;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import ru.sparkcheck.gui.ReportReasonMenu;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/** /report <ник> - открывает меню выбора причины. */
public final class ReportCommand implements TabExecutor {
    private final SparkCheck plugin;

    public ReportCommand(SparkCheck plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!(s instanceof Player p)) {
            s.sendMessage(plugin.msg("player-only"));
            return true;
        }
        if (!p.hasPermission("sparkcheck.report")) {
            p.sendMessage(plugin.msg("no-permission"));
            return true;
        }
        if (a.length < 1) {
            p.sendMessage(plugin.msg("report-usage"));
            return true;
        }

        UUID uuid;
        String name;
        Player online = Bukkit.getPlayerExact(a[0]);
        if (online != null) {
            uuid = online.getUniqueId();
            name = online.getName();
        } else {
            OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(a[0]);      // жаловаться можно и на вышедшего игрока
            if (op == null || !op.hasPlayedBefore()) {
                p.sendMessage(plugin.msg("report-player-not-found"));
                return true;
            }
            uuid = op.getUniqueId();
            name = Util.clean(op.getName() != null ? op.getName() : a[0]);
        }

        Component err = plugin.reports().precheck(p, uuid, name);
        if (err != null) {
            p.sendMessage(err);
            return true;
        }
        new ReportReasonMenu(plugin, uuid, name).open(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length != 1) return out;
        String prefix = a[0].toLowerCase(Locale.ROOT);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (s instanceof Player self && self.getUniqueId().equals(p.getUniqueId())) continue;
            if (p.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) out.add(p.getName());
        }
        return out;
    }
}
