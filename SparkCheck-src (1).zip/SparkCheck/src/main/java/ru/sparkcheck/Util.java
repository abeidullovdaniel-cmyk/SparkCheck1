package ru.sparkcheck;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class Util {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private Util() {
    }

    /** Строка с &-цветами -> Component (без курсива по умолчанию). */
    public static Component c(String s) {
        return LEGACY.deserialize(s).decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    /** Убирает цветовые коды из текста, который прислал игрок. */
    public static String clean(String s) {
        return s == null ? "" : s.replace("&", "").replace("§", "");
    }

    public static String time(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format("%02d:%02d", s / 60, s % 60);
    }

    /** Формат чата: текст игрока вставляется как обычный текст, его &-коды не работают. */
    public static Component chat(String fmt, String from, String to, String message) {
        int i = fmt.indexOf("%message%");
        String before = (i < 0 ? fmt : fmt.substring(0, i)).replace("%player%", from).replace("%target%", to);
        String after = i < 0 ? "" : fmt.substring(i + 9).replace("%player%", from).replace("%target%", to);
        return c(before).append(Component.text(message, NamedTextColor.WHITE)).append(c(after));
    }

    public static ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(c(name));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(c(s));
            meta.lore(l);
        }
        it.setItemMeta(meta);
        return it;
    }

    public static ItemStack head(UUID uuid, String name, String... lore) {
        ItemStack it = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) it.getItemMeta();
        meta.setOwningPlayer(Bukkit.getOfflinePlayer(uuid));
        meta.displayName(c(name));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(c(s));
            meta.lore(l);
        }
        it.setItemMeta(meta);
        return it;
    }

    private static final DateTimeFormatter STAMP =
            DateTimeFormatter.ofPattern("dd.MM HH:mm").withZone(ZoneId.systemDefault());
    private static final DateTimeFormatter HHMM =
            DateTimeFormatter.ofPattern("HH:mm").withZone(ZoneId.systemDefault());

    public static String stamp(long ms) {
        return STAMP.format(Instant.ofEpochMilli(ms));
    }

    public static String hhmm(long ms) {
        return HHMM.format(Instant.ofEpochMilli(ms));
    }

    /** "5 мин", "3 ч", "2 дн" */
    public static String ago(long ms) {
        long m = Math.max(0, ms / 60_000);
        if (m < 1) return "меньше минуты";
        if (m < 60) return m + " мин";
        long h = m / 60;
        if (h < 48) return h + " ч";
        return (h / 24) + " дн";
    }

    private static ItemStack fillerCache;

    public static ItemStack filler() {
        if (fillerCache == null) fillerCache = item(Material.GRAY_STAINED_GLASS_PANE, " ");
        return fillerCache.clone();
    }
}
