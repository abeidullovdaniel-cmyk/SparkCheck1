package ru.sparkcheck;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Locale;

/** /confess - проверяемый игрок признаётся в использовании читов. */
public final class ConfessCommand implements CommandExecutor {
    private final SparkCheck plugin;

    public ConfessCommand(SparkCheck plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!(s instanceof Player p)) {
            s.sendMessage(plugin.msg("player-only"));
            return true;
        }
        if (!p.hasPermission("sparkcheck.confess")) {
            p.sendMessage(plugin.msg("no-permission"));
            return true;
        }
        boolean confirm = false;
        if (a.length > 0) {
            String x = a[0].toLowerCase(Locale.ROOT);
            confirm = x.equals("confirm") || x.equals("подтвердить") || x.equals("да") || x.equals("yes");
        }
        plugin.manager().confess(p, confirm);
        return true;
    }
}
