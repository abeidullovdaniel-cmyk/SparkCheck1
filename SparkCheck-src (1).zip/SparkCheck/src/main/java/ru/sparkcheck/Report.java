package ru.sparkcheck;

import java.util.UUID;

/** Жалоба игрока на другого игрока. */
public final class Report {
    public enum Status {
        OPEN("Открыт"),
        TAKEN("Взят в работу"),
        CONFIRMED("Подтверждён"),
        REJECTED("Отклонён");

        public final String title;

        Status(String title) {
            this.title = title;
        }
    }

    public final int id;
    public final UUID reporter;
    public final String reporterName;
    public final UUID target;
    public final String targetName;
    public final String reasonKey;
    public final String reasonTitle;     // без цветовых кодов
    public final long time;

    public Status status = Status.OPEN;
    public UUID moderator;
    public String moderatorName = "";
    public long takenAt;
    public long closedAt;

    public Report(int id, UUID reporter, String reporterName, UUID target, String targetName,
                  String reasonKey, String reasonTitle, long time) {
        this.id = id;
        this.reporter = reporter;
        this.reporterName = reporterName;
        this.target = target;
        this.targetName = targetName;
        this.reasonKey = reasonKey;
        this.reasonTitle = reasonTitle;
        this.time = time;
    }
}
