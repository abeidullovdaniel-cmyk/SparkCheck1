package ru.sparkcheck;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.List;
import java.util.Locale;

/** Ограничения для проверяемого игрока, приватный чат проверки, выход игроков. */
public final class CheckListener implements Listener {
    private final SparkCheck plugin;
    private final CheckManager m;

    public CheckListener(SparkCheck plugin, CheckManager manager) {
        this.plugin = plugin;
        this.m = manager;
    }

    // ---------- заморозка и ограничения ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!m.hasSessions()) return;
        CheckSession s = m.get(e.getPlayer().getUniqueId());
        if (s == null || !s.frozen) return;
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ()) {
            Location fixed = from.clone();       // смотреть по сторонам можно, ходить нельзя
            fixed.setY(Math.min(from.getY(), to.getY()));   // но падать вниз можно - не зависнет в воздухе
            fixed.setYaw(to.getYaw());
            fixed.setPitch(to.getPitch());
            e.setTo(fixed);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        if (!m.hasSessions() || !m.isChecked(e.getPlayer().getUniqueId())) return;
        switch (e.getCause()) {
            case ENDER_PEARL, CHORUS_FRUIT, COMMAND, NETHER_PORTAL, END_PORTAL -> e.setCancelled(true);
            default -> {
            }
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (m.hasSessions() && m.isChecked(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (m.hasSessions() && m.isChecked(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (m.hasSessions() && m.isChecked(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (m.hasSessions() && m.isChecked(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent e) {
        if (m.hasSessions() && e.getEntity() instanceof Player p && m.isChecked(p.getUniqueId())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (m.hasSessions() && plugin.isInvulnerable() && e.getEntity() instanceof Player p
                && m.isChecked(p.getUniqueId())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (m.hasSessions() && e.getDamager() instanceof Player p && m.isChecked(p.getUniqueId())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInventory(InventoryClickEvent e) {
        if (!m.hasSessions() || !plugin.isBlockInventory()) return;
        if (e.getWhoClicked() instanceof Player p && m.isChecked(p.getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!m.hasSessions() || !m.isChecked(e.getPlayer().getUniqueId())) return;
        String msg = e.getMessage();
        String label = msg.length() > 1 ? msg.substring(1).split(" ")[0].toLowerCase(Locale.ROOT) : "";
        int colon = label.indexOf(':');
        if (colon >= 0) label = label.substring(colon + 1);
        if (plugin.isConfessLabel(label)) return;               // /confess всегда доступна проверяемому
        if (plugin.isCommandAllowed(label)) return;
        e.setCancelled(true);
        e.getPlayer().sendMessage(plugin.msg("command-blocked"));
    }

    // ---------- приватный чат проверки ----------

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        if (!m.hasSessions()) return;
        Player p = e.getPlayer();
        String plain = PlainTextComponentSerializer.plainText().serialize(e.message());

        CheckSession s = m.get(p.getUniqueId());
        if (s != null) {                                     // пишет проверяемый
            e.setCancelled(true);
            Bukkit.getScheduler().runTask(plugin, () -> m.suspectSaid(s, plain));
            return;
        }
        List<CheckSession> mine = m.sessionsOf(p.getUniqueId());
        if (mine.isEmpty()) return;
        if (!plugin.isModChatPrivate()) return;          // кэш: из async-потока конфиг не читаем
        if (plain.startsWith("!")) {                         // "!текст" - в общий чат
            e.message(Component.text(plain.substring(1).stripLeading()));
            return;
        }
        e.setCancelled(true);
        Bukkit.getScheduler().runTask(plugin, () -> m.moderatorSaid(p, mine, plain));
    }

    // ---------- выход ----------

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.stopViewing(e.getPlayer());
        if (!m.hasSessions()) return;
        Player p = e.getPlayer();
        CheckSession s = m.get(p.getUniqueId());
        if (s != null) m.finish(s, Verdict.QUIT, p.getName());
        for (CheckSession ms : m.sessionsOf(p.getUniqueId())) {   // вышел модератор - проверку снимаем
            m.finish(ms, Verdict.CANCELLED, p.getName());
        }
    }
}
