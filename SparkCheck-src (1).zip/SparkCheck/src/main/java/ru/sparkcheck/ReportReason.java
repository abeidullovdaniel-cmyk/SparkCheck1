package ru.sparkcheck;

import org.bukkit.Material;

import java.util.List;

/** Причина репорта из config.yml (report.reasons). */
public record ReportReason(String key, String name, Material material, List<String> description) {
}
