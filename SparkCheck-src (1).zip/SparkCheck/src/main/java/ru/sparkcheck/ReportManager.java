package ru.sparkcheck;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Репорты игроков: создание, список для модераторов, "взять на себя", закрытие, хранение в reports.yml. */
public final class ReportManager {
    private static final int MAX_CLOSED = 100;

    private final SparkCheck plugin;
    private final File file;
    private final List<Report> reports = new ArrayList<>();
    private final Map<UUID, Long> lastReport = new ConcurrentHashMap<>();
    private int nextId = 1;
    private boolean dirty;
    private final Object fileLock = new Object();

    public ReportManager(SparkCheck plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "reports.yml");
        load();
    }

    // ---------------- списки ----------------

    public Report byId(int id) {
        for (Report r : reports) {
            if (r.id == id) return r;
        }
        return null;
    }

    /** Свободные репорты (их видят все модераторы), старые сверху. */
    public List<Report> open() {
        List<Report> out = new ArrayList<>();
        for (Report r : reports) {
            if (r.status == Report.Status.OPEN) out.add(r);
        }
        out.sort(Comparator.comparingLong(r -> r.time));
        return out;
    }

    /** Репорты, которые взял этот модератор. */
    public List<Report> takenBy(UUID moderator) {
        List<Report> out = new ArrayList<>();
        for (Report r : reports) {
            if (r.status == Report.Status.TAKEN && moderator.equals(r.moderator)) out.add(r);
        }
        out.sort(Comparator.comparingLong(r -> r.takenAt));
        return out;
    }

    public int openCount() {
        int n = 0;
        for (Report r : reports) {
            if (r.status == Report.Status.OPEN) n++;
        }
        return n;
    }

    /** Сколько неразобранных жалоб на игрока (открытых и взятых). */
    public int activeOn(UUID target) {
        int n = 0;
        for (Report r : reports) {
            if ((r.status == Report.Status.OPEN || r.status == Report.Status.TAKEN) && r.target.equals(target)) n++;
        }
        return n;
    }

    // ---------------- отправка ----------------

    /** Проверки до открытия меню причин. null = можно жаловаться. */
    public Component precheck(Player reporter, UUID target, String targetName) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("report.enabled", true)) return plugin.msg("report-disabled");
        if (reporter.getUniqueId().equals(target)) return plugin.msg("report-self");
        Player online = Bukkit.getPlayer(target);
        if (online != null && online.hasPermission("sparkcheck.bypass")
                && !c.getBoolean("report.allow-report-staff", false)) {
            return plugin.msg("report-staff");
        }
        long now = System.currentTimeMillis();
        long cd = c.getInt("report.cooldown-seconds", 30) * 1000L;
        Long last = lastReport.get(reporter.getUniqueId());
        if (last != null && now - last < cd) {
            return plugin.msg("report-cooldown", "%seconds%", String.valueOf((cd - (now - last)) / 1000 + 1));
        }
        long dup = c.getInt("report.duplicate-minutes", 10) * 60_000L;
        int open = 0;
        for (Report r : reports) {
            if (!r.reporter.equals(reporter.getUniqueId())) continue;
            if (r.status == Report.Status.OPEN || r.status == Report.Status.TAKEN) open++;
            if (r.target.equals(target) && now - r.time < dup) return plugin.msg("report-duplicate", "%player%", targetName);
        }
        if (open >= c.getInt("report.max-open-per-player", 5)) return plugin.msg("report-limit");
        return null;
    }

    /** Создать репорт. @return null при успехе, иначе сообщение об ошибке. */
    public Component submit(Player reporter, UUID target, String targetName, String reasonKey) {
        Component err = precheck(reporter, target, targetName);
        if (err != null) return err;
        ReportReason reason = null;
        for (ReportReason r : plugin.reasons()) {
            if (r.key().equals(reasonKey)) reason = r;
        }
        if (reason == null) return plugin.msg("report-bad-reason");

        long now = System.currentTimeMillis();
        Report r = new Report(nextId++, reporter.getUniqueId(), reporter.getName(), target, targetName,
                reason.key(), Util.clean(reason.name()), now);
        reports.add(r);
        lastReport.put(reporter.getUniqueId(), now);
        dirty = true;

        reporter.sendMessage(plugin.msg("report-sent", "%player%", targetName, "%reason%", r.reasonTitle));

        // сообщение модераторам в чат с кнопкой "Взять"
        Component line = plugin.msg("report-notify", "%id%", String.valueOf(r.id), "%reporter%", r.reporterName,
                "%target%", r.targetName, "%reason%", r.reasonTitle, "%time%", Util.hhmm(r.time),
                "%count%", String.valueOf(activeOn(target)));
        Component button = plugin.raw("report-take-button")
                .clickEvent(ClickEvent.runCommand("/sparkcheck reports take " + r.id))
                .hoverEvent(HoverEvent.showText(plugin.raw("report-take-hover")));
        for (Player o : Bukkit.getOnlinePlayers()) {
            if (o.hasPermission("sparkcheck.reports.notify")) {
                o.sendMessage(line.append(button));
                o.playSound(o.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1f, 1.2f);
            }
        }
        Bukkit.getConsoleSender().sendMessage(line);
        return null;
    }

    // ---------------- работа модератора ----------------

    /** Взять репорт на себя - у остальных модераторов он пропадает из списка. */
    public Component take(int id, Player mod) {
        Report r = byId(id);
        if (r == null) return plugin.msg("report-not-found");
        if (r.status != Report.Status.OPEN) {
            return plugin.msg("report-already-taken", "%moderator%", r.moderatorName.isEmpty() ? "—" : r.moderatorName);
        }
        r.status = Report.Status.TAKEN;
        r.moderator = mod.getUniqueId();
        r.moderatorName = mod.getName();
        r.takenAt = System.currentTimeMillis();
        dirty = true;
        mod.sendMessage(plugin.msg("report-taken", "%id%", String.valueOf(r.id), "%player%", r.targetName));
        if (plugin.getConfig().getBoolean("report.notify-taken", true)) {
            Component note = plugin.msg("report-taken-notify", "%moderator%", mod.getName(),
                    "%id%", String.valueOf(r.id), "%player%", r.targetName);
            for (Player o : Bukkit.getOnlinePlayers()) {
                if (o.hasPermission("sparkcheck.reports.notify") && !o.getUniqueId().equals(mod.getUniqueId())) {
                    o.sendMessage(note);
                }
            }
        }
        return null;
    }

    /** Вернуть репорт в общий список. */
    public void release(Report r) {
        if (r.status != Report.Status.TAKEN) return;
        r.status = Report.Status.OPEN;
        r.moderator = null;
        r.moderatorName = "";
        r.takenAt = 0;
        dirty = true;
    }

    /** Закрыть репорт (CONFIRMED или REJECTED), уведомить жалобщика. */
    public void close(Report r, Report.Status status) {
        if (r.status == Report.Status.CONFIRMED || r.status == Report.Status.REJECTED) return;
        r.status = status;
        r.closedAt = System.currentTimeMillis();
        dirty = true;

        Player rp = Bukkit.getPlayer(r.reporter);
        if (rp != null) {
            rp.sendMessage(plugin.msg(status == Report.Status.CONFIRMED ? "report-closed-confirmed"
                    : "report-closed-rejected", "%player%", r.targetName));
        }
        Player mod = r.moderator == null ? null : Bukkit.getPlayer(r.moderator);
        if (mod != null) {
            mod.sendMessage(plugin.msg("report-closed-mod", "%id%", String.valueOf(r.id), "%status%", status.title));
        }
        if (status == Report.Status.CONFIRMED) {
            for (String raw : plugin.getConfig().getStringList("report.confirmed-commands")) {
                String cmd = raw.replace("%reporter%", r.reporterName).replace("%target%", r.targetName).trim();
                if (cmd.startsWith("/")) cmd = cmd.substring(1);
                if (!cmd.isEmpty()) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            }
        }
    }

    /** Итог проверки, начатой из репорта: нарушение -> подтверждён, "Чист" -> отклонён. */
    public void autoClose(int id, Verdict v) {
        Report r = byId(id);
        if (r == null || r.status != Report.Status.TAKEN || v == Verdict.CANCELLED) return;
        close(r, v == Verdict.CLEAN ? Report.Status.REJECTED : Report.Status.CONFIRMED);
    }

    // ---------------- хранение ----------------

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        nextId = Math.max(1, y.getInt("next-id", 1));
        for (Map<?, ?> m : y.getMapList("reports")) {
            try {
                Report r = new Report(num(m.get("id")).intValue(), UUID.fromString(str(m.get("reporter"))),
                        str(m.get("reporterName")), UUID.fromString(str(m.get("target"))), str(m.get("targetName")),
                        str(m.get("reason")), str(m.get("reasonTitle")), num(m.get("time")));
                r.status = Report.Status.valueOf(str(m.get("status")));
                String mod = str(m.get("moderator"));
                r.moderator = mod.isEmpty() ? null : UUID.fromString(mod);
                r.moderatorName = str(m.get("moderatorName"));
                r.takenAt = num(m.get("takenAt"));
                r.closedAt = num(m.get("closedAt"));
                reports.add(r);
                nextId = Math.max(nextId, r.id + 1);
            } catch (IllegalArgumentException ignored) {
                // повреждённая запись - пропускаем
            }
        }
    }

    /** Записать reports.yml на диск, если были изменения. async=true - запись в отдельном потоке. */
    public void flush(boolean async) {
        if (!dirty) return;
        dirty = false;
        // храним не больше MAX_CLOSED закрытых репортов
        List<Report> closed = new ArrayList<>();
        for (Report r : reports) {
            if (r.status == Report.Status.CONFIRMED || r.status == Report.Status.REJECTED) closed.add(r);
        }
        if (closed.size() > MAX_CLOSED) {
            closed.sort(Comparator.comparingLong(r -> r.closedAt));
            for (int i = 0; i < closed.size() - MAX_CLOSED; i++) reports.remove(closed.get(i));
        }

        YamlConfiguration y = new YamlConfiguration();
        y.set("next-id", nextId);
        List<Map<String, Object>> list = new ArrayList<>();
        for (Report r : reports) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", r.id);
            m.put("reporter", r.reporter.toString());
            m.put("reporterName", r.reporterName);
            m.put("target", r.target.toString());
            m.put("targetName", r.targetName);
            m.put("reason", r.reasonKey);
            m.put("reasonTitle", r.reasonTitle);
            m.put("time", r.time);
            m.put("status", r.status.name());
            m.put("moderator", r.moderator == null ? "" : r.moderator.toString());
            m.put("moderatorName", r.moderatorName);
            m.put("takenAt", r.takenAt);
            m.put("closedAt", r.closedAt);
            list.add(m);
        }
        y.set("reports", list);
        String data = y.saveToString();
        Runnable write = () -> {
            synchronized (fileLock) {
                try {
                    Files.createDirectories(file.getParentFile().toPath());
                    Files.writeString(file.toPath(), data, StandardCharsets.UTF_8);
                } catch (IOException e) {
                    plugin.getLogger().warning("Не удалось сохранить reports.yml: " + e.getMessage());
                }
            }
        };
        if (async && plugin.isEnabled()) Bukkit.getScheduler().runTaskAsynchronously(plugin, write);
        else write.run();
    }

    /** Раз в минуту: чистим старые кулдауны, возвращаем репорты, застрявшие у ушедших модераторов. */
    public void maintenance() {
        long now = System.currentTimeMillis();
        lastReport.values().removeIf(t -> now - t > 3_600_000L);
        long limit = plugin.getConfig().getInt("report.auto-release-minutes", 30) * 60_000L;
        if (limit <= 0) return;
        for (Report r : reports) {
            if (r.status == Report.Status.TAKEN && r.moderator != null && now - r.takenAt > limit
                    && Bukkit.getPlayer(r.moderator) == null) {
                release(r);
            }
        }
    }

    /** Сколько неразобранных жалоб на каждого игрока (один проход вместо подсчёта на каждый предмет меню). */
    public Map<UUID, Integer> activeCounts() {
        Map<UUID, Integer> out = new java.util.HashMap<>();
        for (Report r : reports) {
            if (r.status == Report.Status.OPEN || r.status == Report.Status.TAKEN) out.merge(r.target, 1, Integer::sum);
        }
        return out;
    }

    private static String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    private static Long num(Object o) {
        return o instanceof Number n ? n.longValue() : 0L;
    }
}
