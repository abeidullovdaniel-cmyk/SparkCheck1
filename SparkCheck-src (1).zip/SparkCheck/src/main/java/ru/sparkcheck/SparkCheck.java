package ru.sparkcheck;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import ru.sparkcheck.gui.GuiListener;
import ru.sparkcheck.gui.HistoryMenu;
import ru.sparkcheck.gui.MainMenu;
import ru.sparkcheck.gui.ReportControlMenu;
import ru.sparkcheck.gui.ReportsMenu;
import ru.sparkcheck.gui.RoomsMenu;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class SparkCheck extends JavaPlugin implements TabExecutor {
    private CheckManager manager;
    private ReportManager reports;
    /** Модераторы, которые сейчас смотрят чужой инвентарь (клики блокируются). */
    private final Set<UUID> viewing = ConcurrentHashMap.newKeySet();
    private final Set<String> confessLabels = new HashSet<>();

    // настройки, которые читаются часто или из async-потоков (чат) - кэшируем
    private volatile boolean invulnerable = true;
    private volatile boolean blockInventory;
    private volatile boolean modChatPrivate = true;
    private volatile Set<String> allowedCommands = Set.of();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        manager = new CheckManager(this);
        reports = new ReportManager(this);
        getServer().getPluginManager().registerEvents(new CheckListener(this, manager), this);
        getServer().getPluginManager().registerEvents(new GuiListener(this), this);

        PluginCommand cmd = getCommand("sparkcheck");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        PluginCommand confess = getCommand("confess");
        confessLabels.add("confess");
        if (confess != null) {
            confess.setExecutor(new ConfessCommand(this));
            confessLabels.add(confess.getName().toLowerCase(Locale.ROOT));
            for (String a : confess.getAliases()) confessLabels.add(a.toLowerCase(Locale.ROOT));
        }
        PluginCommand report = getCommand("report");
        if (report != null) {
            ReportCommand rc = new ReportCommand(this);
            report.setExecutor(rc);
            report.setTabCompleter(rc);
        }
        manager.startTimer();
        // запись history.yml / reports.yml - не чаще раза в 5 секунд и не в основном потоке
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            manager.flush(true);
            reports.flush(true);
        }, 100L, 100L);
        Bukkit.getScheduler().runTaskTimer(this, () -> reports.maintenance(), 1200L, 1200L);
        getLogger().info("SparkCheck включён.");
    }

    @Override
    public void onDisable() {
        if (manager != null) {
            manager.shutdown();
            manager.flush(false);
        }
        if (reports != null) reports.flush(false);
    }

    public CheckManager manager() {
        return manager;
    }

    public ReportManager reports() {
        return reports;
    }

    /** Причины репорта из config.yml (report.reasons) в порядке записи. */
    public List<ReportReason> reasons() {
        List<ReportReason> out = new ArrayList<>();
        ConfigurationSection sec = getConfig().getConfigurationSection("report.reasons");
        if (sec == null) return out;
        for (String key : sec.getKeys(false)) {
            ConfigurationSection r = sec.getConfigurationSection(key);
            if (r == null) continue;
            Material m = Material.matchMaterial(r.getString("material", "PAPER"));
            out.add(new ReportReason(key, r.getString("name", key), m == null ? Material.PAPER : m,
                    r.getStringList("description")));
        }
        return out;
    }

    /** Читает настройки, которые нужны слушателям (в том числе из async-потока чата). */
    public void loadSettings() {
        invulnerable = getConfig().getBoolean("invulnerable", true);
        blockInventory = getConfig().getBoolean("block-inventory", false);
        modChatPrivate = "private".equalsIgnoreCase(getConfig().getString("moderator-chat", "private"));
        Set<String> set = new HashSet<>();
        for (String a : getConfig().getStringList("allowed-commands")) {
            set.add(a.replace("/", "").toLowerCase(Locale.ROOT));
        }
        allowedCommands = set;
    }

    public boolean isInvulnerable() {
        return invulnerable;
    }

    public boolean isBlockInventory() {
        return blockInventory;
    }

    public boolean isModChatPrivate() {
        return modChatPrivate;
    }

    public boolean isCommandAllowed(String label) {
        return allowedCommands.contains(label);
    }

    public boolean isConfessLabel(String label) {
        return confessLabels.contains(label);
    }

    /** Проверка права с сообщением об отказе. */
    public boolean has(Player p, String perm) {
        if (p.hasPermission(perm)) return true;
        p.sendMessage(msg("no-permission"));
        return false;
    }

    // ---------- просмотр инвентаря ----------

    public void startViewing(Player p) {
        viewing.add(p.getUniqueId());
    }

    public void stopViewing(Player p) {
        viewing.remove(p.getUniqueId());
    }

    public boolean isViewing(Player p) {
        return viewing.contains(p.getUniqueId());
    }

    // ---------- сообщения из config.yml ----------

    private String cfg(String key) {
        return getConfig().getString("messages." + key, "&c[нет сообщения: " + key + "]");
    }

    private static String apply(String s, String... r) {
        for (int i = 0; i + 1 < r.length; i += 2) s = s.replace(r[i], r[i + 1]);
        return s;
    }

    public boolean hasMessage(String key) {
        return getConfig().isString("messages." + key);
    }

    /** Сообщение с префиксом. */
    public Component msg(String key, String... r) {
        return Util.c(cfg("prefix") + apply(cfg(key), r));
    }

    /** Сообщение без префикса. */
    public Component raw(String key, String... r) {
        return Util.c(apply(cfg(key), r));
    }

    public List<Component> list(String key, String... r) {
        List<Component> out = new ArrayList<>();
        for (String s : getConfig().getStringList("messages." + key)) out.add(Util.c(apply(s, r)));
        return out;
    }

    /** Личное сообщение: %player% - кто пишет, %target% - кому, %message% - текст игрока. */
    public Component chat(String key, String from, String to, String message) {
        return Util.chat(cfg(key), from, to, message);
    }

    // ---------- команды ----------

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (!s.hasPermission("sparkcheck.use")) {
            s.sendMessage(msg("no-permission"));
            return true;
        }
        String sub = a.length == 0 ? "gui" : a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "gui" -> {
                if (s instanceof Player p) new MainMenu(this, p, 0).open(p);
                else s.sendMessage(msg("player-only"));
            }
            case "history" -> {
                if (!s.hasPermission("sparkcheck.history")) s.sendMessage(msg("no-permission"));
                else if (s instanceof Player p) new HistoryMenu(this).open(p);
                else s.sendMessage(msg("player-only"));
            }
            case "list" -> list(s);
            case "end" -> end(s, a);
            case "reports" -> reportsCmd(s, a);
            case "rooms" -> rooms(s);
            case "room" -> defaultRoom(s, a);
            case "setroom" -> setRoom(s, a);
            case "delroom" -> delRoom(s, a);
            case "reload" -> {
                if (!s.hasPermission("sparkcheck.reload")) {
                    s.sendMessage(msg("no-permission"));
                } else {
                    reloadConfig();
                    loadSettings();
                    s.sendMessage(msg("reloaded"));
                }
            }
            case "help" -> {
                for (Component line : list("help")) s.sendMessage(line);
            }
            default -> startByName(s, a[0], a.length > 1 ? a[1] : null);
        }
        return true;
    }

    private void startByName(CommandSender s, String name, String room) {
        if (!(s instanceof Player mod)) {
            s.sendMessage(msg("player-only"));
            return;
        }
        Player target = Bukkit.getPlayerExact(name);
        if (target == null) {
            s.sendMessage(msg("player-not-found"));
            return;
        }
        Component err = manager.start(mod, target, room);
        if (err != null) s.sendMessage(err);
    }

    private void list(CommandSender s) {
        Collection<CheckSession> all = manager.all();
        if (all.isEmpty()) {
            s.sendMessage(msg("list-empty"));
            return;
        }
        for (CheckSession cs : all) {
            s.sendMessage(msg("list-entry", "%player%", cs.suspectName, "%moderator%", cs.moderatorName,
                    "%time%", Util.time(cs.left())));
        }
    }

    private void end(CommandSender s, String[] a) {
        if (a.length < 3) {
            s.sendMessage(msg("end-usage"));
            return;
        }
        CheckSession target = null;
        for (CheckSession cs : manager.all()) {
            if (cs.suspectName.equalsIgnoreCase(a[1])) target = cs;
        }
        if (target == null) {
            s.sendMessage(msg("not-checked"));
            return;
        }
        Verdict v = switch (a[2].toLowerCase(Locale.ROOT)) {
            case "clean" -> Verdict.CLEAN;
            case "cheats" -> Verdict.CHEATS;
            case "refused" -> Verdict.REFUSED;
            case "cancel" -> Verdict.CANCELLED;
            default -> null;
        };
        if (v == null) {
            s.sendMessage(msg("end-usage"));
            return;
        }
        String perm = switch (v) {
            case CLEAN -> "sparkcheck.verdict.clean";
            case CANCELLED -> "sparkcheck.verdict.cancel";
            default -> "sparkcheck.verdict.punish";
        };
        if (!s.hasPermission(perm)) {
            s.sendMessage(msg("no-permission"));
            return;
        }
        manager.finish(target, v, s.getName());
    }

    // ---------- репорты ----------

    /** /sparkcheck reports [take <id> | release <id>] */
    private void reportsCmd(CommandSender s, String[] a) {
        if (!s.hasPermission("sparkcheck.reports")) {
            s.sendMessage(msg("no-permission"));
            return;
        }
        if (!(s instanceof Player p)) {
            s.sendMessage(msg("player-only"));
            return;
        }
        String act = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "";
        if (act.equals("take") || act.equals("release")) {
            int id;
            try {
                id = a.length > 2 ? Integer.parseInt(a[2]) : -1;
            } catch (NumberFormatException e) {
                id = -1;
            }
            Report r = id < 0 ? null : reports.byId(id);
            if (r == null) {
                p.sendMessage(msg("report-not-found"));
                return;
            }
            if (act.equals("take")) {
                if (r.status == Report.Status.TAKEN && p.getUniqueId().equals(r.moderator)) {
                    new ReportControlMenu(this, r).open(p);          // свой репорт - просто открыть управление
                    return;
                }
                Component err = reports.take(id, p);
                if (err != null) {
                    p.sendMessage(err);
                    return;
                }
                new ReportControlMenu(this, r).open(p);
            } else {
                if (r.status != Report.Status.TAKEN) {
                    p.sendMessage(msg("report-not-found"));
                    return;
                }
                boolean own = p.getUniqueId().equals(r.moderator);
                if (!own && !p.hasPermission("sparkcheck.reports.manage")) {
                    p.sendMessage(msg("report-not-yours", "%moderator%", r.moderatorName));
                    return;
                }
                reports.release(r);
                p.sendMessage(msg("report-released", "%id%", String.valueOf(id)));
            }
            return;
        }
        new ReportsMenu(this, p, false, 0).open(p);
    }

    // ---------- места проверки ----------

    private void rooms(CommandSender s) {
        if (!s.hasPermission("sparkcheck.room")) {
            s.sendMessage(msg("no-permission"));
            return;
        }
        if (s instanceof Player p) {
            new RoomsMenu(this, null).open(p);
            return;
        }
        List<String> names = manager.roomNames();
        if (names.isEmpty()) {
            s.sendMessage(msg("rooms-empty"));
            return;
        }
        String def = manager.defaultRoomName();
        for (String n : names) {
            Location l = manager.room(n);
            s.sendMessage(msg("rooms-entry", "%room%", n,
                    "%where%", l == null ? "мир не найден" : l.getWorld().getName() + " "
                            + l.getBlockX() + " " + l.getBlockY() + " " + l.getBlockZ(),
                    "%default%", n.equals(def) ? " (по умолчанию)" : ""));
        }
    }

    private void setRoom(CommandSender s, String[] a) {
        if (!s.hasPermission("sparkcheck.room")) {
            s.sendMessage(msg("no-permission"));
            return;
        }
        if (!(s instanceof Player p)) {
            s.sendMessage(msg("player-only"));
            return;
        }
        String name = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "main";
        if (!manager.validRoomName(name)) {
            s.sendMessage(msg("room-invalid-name"));
            return;
        }
        manager.setRoom(name, p.getLocation());
        s.sendMessage(msg("room-set", "%room%", name));
    }

    private void delRoom(CommandSender s, String[] a) {
        if (!s.hasPermission("sparkcheck.room")) {
            s.sendMessage(msg("no-permission"));
            return;
        }
        if (a.length < 2) {
            s.sendMessage(msg("room-usage"));
            return;
        }
        if (manager.deleteRoom(a[1])) s.sendMessage(msg("room-deleted", "%room%", a[1].toLowerCase(Locale.ROOT)));
        else s.sendMessage(msg("room-not-found", "%room%", a[1]));
    }

    /** /sparkcheck room <имя|none> - место по умолчанию. */
    private void defaultRoom(CommandSender s, String[] a) {
        if (!s.hasPermission("sparkcheck.room")) {
            s.sendMessage(msg("no-permission"));
            return;
        }
        if (a.length < 2) {
            s.sendMessage(msg("room-usage"));
            return;
        }
        String n = a[1].toLowerCase(Locale.ROOT);
        if (n.equals("none")) {
            manager.setDefaultRoom("");
            s.sendMessage(msg("room-default-none"));
        } else if (manager.roomExists(n)) {
            manager.setDefaultRoom(n);
            s.sendMessage(msg("room-default-set", "%room%", n));
        } else {
            s.sendMessage(msg("room-not-found", "%room%", a[1]));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (!s.hasPermission("sparkcheck.use")) return out;
        if (a.length == 1) {
            out.addAll(List.of("gui", "list", "history", "end", "reports", "rooms", "room", "setroom", "delroom", "reload", "help"));
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        } else if (a.length == 2 && a[0].equalsIgnoreCase("end")) {
            for (CheckSession cs : manager.all()) out.add(cs.suspectName);
        } else if (a.length == 3 && a[0].equalsIgnoreCase("end")) {
            out.addAll(List.of("clean", "cheats", "refused", "cancel"));
        } else if (a.length == 2 && a[0].equalsIgnoreCase("reports")) {
            out.addAll(List.of("take", "release"));
        } else if (a.length == 2 && (a[0].equalsIgnoreCase("room") || a[0].equalsIgnoreCase("delroom")
                || a[0].equalsIgnoreCase("setroom"))) {
            out.addAll(manager.roomNames());
            if (a[0].equalsIgnoreCase("room")) out.add("none");
        } else if (a.length == 2) {
            out.addAll(manager.roomNames());          // /sparkcheck <игрок> <место>
            return filter(out, a[1]);
        }
        return filter(out, a[a.length - 1]);
    }

    private static List<String> filter(List<String> in, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        in.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(p));
        return in;
    }
}
